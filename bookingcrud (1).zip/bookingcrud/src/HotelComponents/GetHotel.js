import React from 'react'
import {Table,Button} from 'react-bootstrap'
import axios from 'axios'
 

const apiurl='http://localhost:58000/api/hotel';

class HotelList extends React.Component{
    constructor(props){
        super(props);
        this.state={
            error:null,
            hotels:[],
            response:{}           
        }
    }
    componentDidMount(){
        axios.get(apiurl).then(response=>response.data).then((result)=>this.setState({hotels:result},(error)=>this.setState({error})));
    }
    render(){ 
        const{error,hotels}=this.state;
        if(error){
            return(<div>Error:{error.message}</div>)
        }
        else{
            return(
                <div>
                    <Table>
                    <thead><tr><th>Hotel Id</th><th>Hotel</th><th>Hotel Type</th><th>Comments</th></tr></thead> 
                    <tbody>
                        {hotels.map(item=>item.hotelId)}


                        {hotels.map(hotels=>(<tr key={hotels.hotelId}><td>{hotels.hotelId}</td>
                            <td>{hotels.hotelName}</td>
                            <td>{hotels.hotelType}</td>
                            <td>{hotels.comments}</td></tr>))}
                        </tbody>    
                    </Table>
                    <Button>Test</Button>
                </div>
            )
        }
    }
}
export default HotelList;